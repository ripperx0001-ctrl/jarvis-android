# Jarvis Android Starter Project

This is a starter Android Studio project for Jarvis assistant.
It includes:
- Foreground service
- Wake-word hooks (Porcupine placeholder)
- Speech-to-text using Android SpeechRecognizer
- TTS using Android TTS
- Secure Keystore helpers for biometric-protected secrets
- Unlock activity to request biometric auth

Instructions:
1. Import into Android Studio (File → Open) or build with Gradle.
2. Replace WakeWordHelper placeholder with Porcupine or desired wake-word engine and add .ppn models in app/src/main/assets.
3. Grant required permissions on device: Microphone, Accessibility, Notification access, Draw over apps, Ignore battery optimizations.
4. To test, install on a real device, open app, grant permissions, then tap Start Jarvis.
