package com.example.jarvis

import android.content.Context
import android.util.Log

class WakeWordHelper(private val ctx: Context, private val onDetected: () -> Unit) {

    private val TAG = "WakeWordHelper"
    private var running = false

    fun start() {
        Log.i(TAG, "WakeWordHelper started (placeholder). Add Porcupine integration for production.")
        running = true
    }

    fun stop() {
        running = false
    }
}
