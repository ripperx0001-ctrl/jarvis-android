package com.example.jarvis

import android.app.Activity
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.util.Log
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import java.util.concurrent.Executor

@RequiresApi(Build.VERSION_CODES.M)
class UnlockActivity : AppCompatActivity() {
    private val TAG = "UnlockActivity"
    private lateinit var helper: SecureKeystoreHelper
    private lateinit var executor: Executor

    companion object {
        const val RESULT_SECRET = "result_secret"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        helper = SecureKeystoreHelper(this)
        executor = ContextCompat.getMainExecutor(this)

        if (!helper.hasSecret()) {
            setResult(Activity.RESULT_CANCELED)
            finish()
            return
        }

        try {
            val cipher = helper.buildCipherForDecryption()

            val promptInfo = BiometricPrompt.PromptInfo.Builder()
                .setTitle("Authenticate to unlock Jarvis")
                .setSubtitle("Confirm to continue")
                .setNegativeButtonText("Cancel")
                .build()

            val biometricPrompt = BiometricPrompt(this, executor, object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    super.onAuthenticationSucceeded(result)
                    try {
                        val secret = helper.decryptStoredSecret(result.cryptoObject!!.cipher)
                        val out = Intent()
                        out.putExtra(RESULT_SECRET, secret)
                        setResult(Activity.RESULT_OK, out)
                    } catch (e: Exception) {
                        Log.e(TAG, "decrypt failed: ${e.localizedMessage}")
                        setResult(Activity.RESULT_CANCELED)
                    }
                    finish()
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    super.onAuthenticationError(errorCode, errString)
                    setResult(Activity.RESULT_CANCELED)
                    finish()
                }

                override fun onAuthenticationFailed() {
                    super.onAuthenticationFailed()
                }
            })

            biometricPrompt.authenticate(promptInfo, BiometricPrompt.CryptoObject(cipher))
        } catch (e: Exception) {
            Log.e(TAG, "UnlockActivity error: ${e.localizedMessage}")
            setResult(Activity.RESULT_CANCELED)
            finish()
        }
    }
}
