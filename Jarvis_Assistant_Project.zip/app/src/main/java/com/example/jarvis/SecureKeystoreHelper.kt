package com.example.jarvis

import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import android.util.Base64
import android.util.Log
import androidx.annotation.RequiresApi
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

@RequiresApi(Build.VERSION_CODES.M)
class SecureKeystoreHelper(private val ctx: Context) {
    private val TAG = "SecureKeystoreHelper"
    private val KEYSTORE = "AndroidKeyStore"
    private val KEY_ALIAS = "jarvis_secret_key"
    private val PREFS = "jarvis_secure_prefs"
    private val PREF_CIPHER = "cipher_text"
    private val PREF_IV = "cipher_iv"

    private val prefs: SharedPreferences = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    init {
        ensureKeyExists()
    }

    private fun ensureKeyExists() {
        try {
            val ks = KeyStore.getInstance(KEYSTORE)
            ks.load(null)
            if (!ks.containsAlias(KEY_ALIAS)) {
                val keyGenerator = KeyGenerator.getInstance("AES", KEYSTORE)
                val builder = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                    android.security.keystore.KeyGenParameterSpec.Builder(
                        KEY_ALIAS,
                        android.security.keystore.KeyProperties.PURPOSE_ENCRYPT or android.security.keystore.KeyProperties.PURPOSE_DECRYPT
                    )
                        .setBlockModes(android.security.keystore.KeyProperties.BLOCK_MODE_GCM)
                        .setEncryptionPaddings(android.security.keystore.KeyProperties.ENCRYPTION_PADDING_NONE)
                        .setUserAuthenticationRequired(true)
                        .setUserAuthenticationValidityDurationSeconds(-1)
                } else {
                    null
                }
                keyGenerator.init(builder!!.build())
                keyGenerator.generateKey()
                Log.i(TAG, "Keystore key generated")
            }
        } catch (e: Exception) {
            Log.e(TAG, "ensureKeyExists error: ${e.localizedMessage}")
        }
    }

    private fun getKey(): SecretKey? {
        val ks = KeyStore.getInstance(KEYSTORE)
        ks.load(null)
        val entry = ks.getEntry(KEY_ALIAS, null) as? KeyStore.SecretKeyEntry
        return entry?.secretKey
    }

    fun encryptAndStoreSecret(cipherForEncryption: Cipher, plainText: String) {
        try {
            val cipherText = cipherForEncryption.doFinal(plainText.toByteArray(Charsets.UTF_8))
            val iv = cipherForEncryption.iv
            prefs.edit().putString(PREF_CIPHER, Base64.encodeToString(cipherText, Base64.DEFAULT))
                .putString(PREF_IV, Base64.encodeToString(iv, Base64.DEFAULT))
                .apply()
            Log.i(TAG, "Secret encrypted and stored")
        } catch (e: Exception) {
            Log.e(TAG, "encryptAndStoreSecret error: ${e.localizedMessage}")
            throw e
        }
    }

    fun buildCipherForEncryption(): Cipher {
        val transformation = "AES/GCM/NoPadding"
        val cipher = Cipher.getInstance(transformation)
        val key = getKey() ?: throw IllegalStateException("Key not found")
        cipher.init(Cipher.ENCRYPT_MODE, key)
        return cipher
    }

    fun buildCipherForDecryption(): Cipher {
        val iv_b64 = prefs.getString(PREF_IV, null) ?: throw IllegalStateException("No IV stored")
        val iv = Base64.decode(iv_b64, Base64.DEFAULT)
        val transformation = "AES/GCM/NoPadding"
        val cipher = Cipher.getInstance(transformation)
        val key = getKey() ?: throw IllegalStateException("Key not found")
        val spec = GCMParameterSpec(128, iv)
        cipher.init(Cipher.DECRYPT_MODE, key, spec)
        return cipher
    }

    fun decryptStoredSecret(cipher: Cipher): String {
        val ct_b64 = prefs.getString(PREF_CIPHER, null) ?: throw IllegalStateException("No ciphertext stored")
        val cipherText = Base64.decode(ct_b64, Base64.DEFAULT)
        val plain = cipher.doFinal(cipherText)
        return String(plain, Charsets.UTF_8)
    }

    fun hasSecret(): Boolean {
        return prefs.contains(PREF_CIPHER) && prefs.contains(PREF_IV)
    }

    fun clearSecret() {
        prefs.edit().remove(PREF_CIPHER).remove(PREF_IV).apply()
    }
}
