package com.example.jarvis

import android.os.Build
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import java.util.concurrent.Executor
import javax.crypto.Cipher

@RequiresApi(Build.VERSION_CODES.M)
class SetSecretActivity : AppCompatActivity() {
    private val TAG = "SetSecretActivity"
    private lateinit var helper: SecureKeystoreHelper
    private lateinit var executor: Executor

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_set_secret)

        helper = SecureKeystoreHelper(this)
        executor = ContextCompat.getMainExecutor(this)

        val etSecret = findViewById<EditText>(R.id.etSecret)
        val btnSave = findViewById<Button>(R.id.btnSave)
        val btnClear = findViewById<Button>(R.id.btnClear)

        btnSave.setOnClickListener {
            val s = etSecret.text.toString().trim()
            if (s.isEmpty()) return@setOnClickListener

            try {
                val cipher = helper.buildCipherForEncryption()

                val promptInfo = BiometricPrompt.PromptInfo.Builder()
                    .setTitle("Authenticate to save your Jarvis secret")
                    .setSubtitle("Use fingerprint or device credential")
                    .setNegativeButtonText("Cancel")
                    .build()

                val biometricPrompt = BiometricPrompt(this, executor, object : BiometricPrompt.AuthenticationCallback() {
                    override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                        super.onAuthenticationSucceeded(result)
                        try {
                            helper.encryptAndStoreSecret(result.cryptoObject!!.cipher, s)
                            runOnUiThread { finish() }
                        } catch (e: Exception) {
                            Log.e(TAG, "store failed: ${e.localizedMessage}")
                        }
                    }

                    override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                        super.onAuthenticationError(errorCode, errString)
                    }

                    override fun onAuthenticationFailed() {
                        super.onAuthenticationFailed()
                    }
                })

                biometricPrompt.authenticate(promptInfo, BiometricPrompt.CryptoObject(cipher))
            } catch (e: Exception) {
                Log.e(TAG, "cipher build error: ${e.localizedMessage}")
            }
        }

        btnClear.setOnClickListener {
            helper.clearSecret()
            finish()
        }
    }
}
