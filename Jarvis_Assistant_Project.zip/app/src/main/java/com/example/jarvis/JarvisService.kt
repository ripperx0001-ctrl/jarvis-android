package com.example.jarvis

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class JarvisService : Service() {

    private val TAG = "JarvisService"
    private var speechHelper: SpeechHelper? = null
    private var tts: TtsHelper? = null
    private var intentHandler: IntentHandler? = null
    private var wakeWordHelper: WakeWordHelper? = null

    private val scope = CoroutineScope(Dispatchers.Main + Job())

    override fun onCreate() {
        super.onCreate()
        tts = TtsHelper(this)
        intentHandler = IntentHandler(this)
        speechHelper = SpeechHelper(this, onResult = { text ->
            Log.d(TAG, "STT got: $text")
            handleCommand(text)
        })

        wakeWordHelper = WakeWordHelper(this) { onWakeWord() }

        startForegroundServiceWithNotification()

        wakeWordHelper?.start()
    }

    private fun startForegroundServiceWithNotification() {
        val notificationIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, notificationIntent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val n: Notification = NotificationCompat.Builder(this, NotificationChannels.CHANNEL_ID)
            .setContentTitle("Jarvis running")
            .setContentText("Listening for \"Zoro\"")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()

        startForeground(NotificationChannels.NOTIFICATION_ID, n)
    }

    private fun onWakeWord() {
        Log.d(TAG, "Wake word detected")
        tts?.speak("Yes?")
        scope.launch { speechHelper?.startListeningOnce() }
    }

    private fun handleCommand(cmd: String) {
        val lower = cmd.lowercase()
        when {
            lower.contains("open youtube") || lower.contains("youtube") -> {
                intentHandler?.openApp("com.google.android.youtube")
                tts?.speak("Opening YouTube")
            }
            lower.contains("stop jarvis") || lower.contains("stop listening") -> {
                tts?.speak("Stopping")
                stopSelf()
            }
            lower.contains("what time") || lower.contains("time") -> {
                val time = java.text.SimpleDateFormat("h:mm a").format(java.util.Date())
                tts?.speak("The time is $time")
            }
            lower.contains("open my phone") || lower.contains("unlock my phone") -> {
                val unlockIntent = Intent(this, UnlockActivity::class.java)
                unlockIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(unlockIntent)
                tts?.speak("Please authenticate to unlock.")
            }
            else -> {
                tts?.speak("I heard: $cmd")
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        wakeWordHelper?.stop()
        speechHelper?.destroy()
        tts?.shutdown()
    }
}
